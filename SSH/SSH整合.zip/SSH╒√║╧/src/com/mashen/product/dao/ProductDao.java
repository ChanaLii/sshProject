package com.mashen.product.dao;


import com.mashen.common.dao.BaseDao;
import com.mashen.product.domain.Product;

public interface ProductDao extends BaseDao<Product>{
	
}
